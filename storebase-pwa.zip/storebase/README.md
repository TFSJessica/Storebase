# StoreBase PWA

Manage your store locations, tasks, and team — installable as an app on any device.

## Deploy Free in 2 Minutes

### Option A: Vercel (Recommended)
1. Go to [vercel.com](https://vercel.com) and create a free account
2. Click "Add New Project"
3. Upload this folder (or drag & drop the zip)
4. Click "Deploy" — done!
5. Share the URL with your team

### Option B: Netlify
1. Go to [netlify.com](https://netlify.com) and create a free account
2. Drag and drop the **build** folder onto the Netlify dashboard
   - First run: `npm install` then `npm run build` to generate the build folder
3. Done — you get a free URL instantly

## Install as an App (after deploying)

### On iPhone/iPad:
1. Open the app URL in Safari
2. Tap the Share button (box with arrow)
3. Tap "Add to Home Screen"
4. Tap "Add" — it now appears as an app icon!

### On Android:
1. Open the app URL in Chrome
2. Tap the menu (3 dots)
3. Tap "Add to Home Screen"

### On Desktop (Chrome/Edge):
1. Open the app URL
2. Click the install icon in the address bar
3. Click "Install"

## Features
- Store locations with address & phone
- Task list linked to stores
- Assign tasks to team members (email alerts)
- Overdue & due-soon warnings
- Works offline after first visit
- All data saved on device
