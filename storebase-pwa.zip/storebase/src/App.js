import { useState, useEffect } from "react";

const load = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
};
const save = (key, val) => localStorage.setItem(key, JSON.stringify(val));

const COLORS = ["#f59e42","#e85d75","#5b8af5","#38c9a0","#a78bfa","#f472b6","#fb923c","#34d399"];

const uid = () => Math.random().toString(36).slice(2,10) + Date.now().toString(36);
const fmtDate = iso => iso ? new Date(iso).toLocaleString("en-US",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}) : "No due date";
const isOverdue = iso => iso && new Date(iso) < new Date();
const isDueSoon = iso => { if(!iso) return false; const d=new Date(iso)-new Date(); return d>0&&d<86400000; };
const initials = name => name.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2);

function simulateSendEmail({ toEmail, taskTitle, storeName, dueDate, note }) {
  console.log("Email would send to:", toEmail, { taskTitle, storeName, dueDate, note });
  return new Promise(res => setTimeout(res, 900));
}

export default function App() {
  const [stores, setStores]   = useState(() => load("sb_stores", []));
  const [todos, setTodos]     = useState(() => load("sb_todos", []));
  const [people, setPeople]   = useState(() => load("sb_people", []));
  const [tab, setTab]         = useState("todos");
  const [toast, setToast]     = useState(null);
  const [sending, setSending] = useState(false);

  const [storeForm, setStoreForm]   = useState(false);
  const [todoForm, setTodoForm]     = useState(false);
  const [personForm, setPersonForm] = useState(false);

  const [sName, setSName] = useState(""); const [sAddr, setSAddr] = useState(""); const [sPhone, setSPhone] = useState("");
  const [tTitle, setTTitle] = useState(""); const [tStore, setTStore] = useState(""); const [tDue, setTDue] = useState("");
  const [tNote, setTNote] = useState(""); const [tPerson, setTPerson] = useState("");
  const [pName, setPName] = useState(""); const [pEmail, setPEmail] = useState(""); const [pRole, setPRole] = useState("");

  const [filterStore, setFilterStore]   = useState("all");
  const [filterPerson, setFilterPerson] = useState("all");
  const [filterStatus, setFilterStatus] = useState("active");

  useEffect(() => save("sb_stores", stores), [stores]);
  useEffect(() => save("sb_todos", todos),   [todos]);
  useEffect(() => save("sb_people", people), [people]);

  const showToast = (msg, type="ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  // in-app due-date poller
  useEffect(() => {
    const check = () => {
      todos.forEach(t => {
        if (!t.done && t.due) {
          const diff = new Date(t.due) - Date.now();
          if (diff > 0 && diff < 60000) {
            setToast({ msg: `⏰ Due now: ${t.title}${t.assigneeName ? " · " + t.assigneeName : ""}`, type: "warn" });
          }
        }
      });
    };
    const id = setInterval(check, 30000);
    return () => clearInterval(id);
  }, [todos]);

  const addStore = () => {
    if (!sName.trim()) return;
    const s = { id: uid(), name: sName.trim(), address: sAddr.trim(), phone: sPhone.trim(), color: COLORS[stores.length % COLORS.length] };
    setStores(p => [...p, s]);
    setSName(""); setSAddr(""); setSPhone(""); setStoreForm(false);
    showToast("📍 " + s.name + " added");
  };
  const deleteStore = id => {
    setStores(p => p.filter(s => s.id !== id));
    setTodos(p => p.map(t => t.storeId === id ? { ...t, storeId: "", storeName: "" } : t));
  };

  const addPerson = () => {
    if (!pName.trim() || !pEmail.trim()) return;
    const p = { id: uid(), name: pName.trim(), email: pEmail.trim(), role: pRole.trim(), color: COLORS[people.length % COLORS.length] };
    setPeople(prev => [...prev, p]);
    setPName(""); setPEmail(""); setPRole(""); setPersonForm(false);
    showToast("👤 " + p.name + " added to team");
  };
  const deletePerson = id => {
    setPeople(p => p.filter(x => x.id !== id));
    setTodos(p => p.map(t => t.assigneeId === id ? { ...t, assigneeId: "", assigneeName: "", assigneeEmail: "" } : t));
  };

  const addTodo = async () => {
    if (!tTitle.trim()) return;
    const store  = stores.find(s => s.id === tStore);
    const person = people.find(p => p.id === tPerson);
    const todo = {
      id: uid(), title: tTitle.trim(),
      storeId: tStore, storeName: store ? store.name : "", storeColor: store ? store.color : "",
      assigneeId: tPerson, assigneeName: person ? person.name : "", assigneeEmail: person ? person.email : "",
      due: tDue, note: tNote.trim(), done: false, created: new Date().toISOString(),
    };
    setTodos(p => [...p, todo]);
    setTTitle(""); setTStore(""); setTDue(""); setTNote(""); setTPerson(""); setTodoForm(false);
    if (person) {
      setSending(true);
      await simulateSendEmail({ toEmail: person.email, taskTitle: todo.title, storeName: store ? store.name : "", dueDate: todo.due, note: todo.note });
      setSending(false);
      showToast("📧 Alert sent to " + person.name + " (" + person.email + ")");
    } else {
      showToast("✅ Task added");
    }
  };

  const toggleDone = id => setTodos(p => p.map(t => t.id === id ? { ...t, done: !t.done } : t));
  const deleteTodo = id => setTodos(p => p.filter(t => t.id !== id));

  const filteredTodos = todos.filter(t => {
    if (filterStore !== "all" && t.storeId !== filterStore) return false;
    if (filterPerson !== "all" && t.assigneeId !== filterPerson) return false;
    if (filterStatus === "active" && t.done) return false;
    if (filterStatus === "done" && !t.done) return false;
    return true;
  });

  const overdueCount = todos.filter(t => !t.done && isOverdue(t.due)).length;
  const pendingCount = todos.filter(t => !t.done).length;

  return (
    <div style={{ minHeight:"100vh", background:"#0c0c10", fontFamily:"'DM Mono',monospace", color:"#eeeae0" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=Syne:wght@700;800;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:#2a2a38;border-radius:2px}
        input,textarea,select{background:#13131c;border:1px solid #252535;color:#eeeae0;font-family:'DM Mono',monospace;font-size:13px;outline:none;transition:border-color .18s;border-radius:8px;padding:10px 12px;width:100%}
        input:focus,textarea:focus,select:focus{border-color:#f59e42}
        input::placeholder,textarea::placeholder{color:#3a3a50}
        select option{background:#13131c}
        textarea{resize:vertical;min-height:72px}
        @keyframes slideDown{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
        .anim-slide{animation:slideDown .2s ease}
        .anim-fade{animation:fadeIn .25s ease}
        .tab-btn{background:none;border:none;cursor:pointer;font-family:'DM Mono',monospace;font-size:12px;letter-spacing:.06em;padding:8px 16px;border-radius:8px;color:#5a5a72;transition:all .15s}
        .tab-btn.active{background:#1e1e2c;color:#eeeae0}
        .tab-btn:hover:not(.active){color:#9898b0}
        .pill{display:inline-flex;align-items:center;gap:5px;padding:3px 11px;border-radius:999px;font-size:11px;font-weight:500}
        .card{background:#111118;border:1px solid #1e1e2c;border-radius:14px;padding:18px;margin-bottom:10px;transition:border-color .15s;animation:fadeIn .2s ease}
        .card:hover{border-color:#2e2e40}
        .btn-primary{background:#f59e42;color:#0c0c10;border:none;border-radius:10px;padding:10px 22px;font-family:'DM Mono',monospace;font-size:13px;font-weight:500;cursor:pointer;transition:background .15s;letter-spacing:.02em}
        .btn-primary:hover{background:#f9b668}
        .btn-primary:disabled{background:#4a3a20;color:#7a6040;cursor:not-allowed}
        .btn-ghost{background:none;border:1px solid #252535;color:#7a7a90;border-radius:10px;padding:10px 18px;font-family:'DM Mono',monospace;font-size:13px;cursor:pointer;transition:all .15s}
        .btn-ghost:hover{border-color:#5a5a72;color:#eeeae0}
        .icon-btn{background:none;border:none;cursor:pointer;padding:5px 7px;border-radius:7px;font-size:14px;opacity:.4;transition:opacity .15s;color:#eeeae0;line-height:1}
        .icon-btn:hover{opacity:1}
        .check-box{width:22px;height:22px;border-radius:7px;border:2px solid #2e2e40;background:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .15s;font-size:12px}
        .check-box.done{background:#38c9a0;border-color:#38c9a0}
        .check-box:hover:not(.done){border-color:#f59e42}
        .filter-pill{background:none;border:1px solid #252535;color:#5a5a72;border-radius:999px;padding:5px 14px;font-family:'DM Mono',monospace;font-size:11px;cursor:pointer;transition:all .15s;white-space:nowrap}
        .filter-pill.active{background:#f59e42;color:#0c0c10;border-color:#f59e42;font-weight:500}
        .filter-pill:hover:not(.active){border-color:#5a5a72;color:#9898b0}
        .avatar{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;flex-shrink:0}
        .form-box{background:#111118;border:1px solid #252535;border-radius:14px;padding:20px;margin-bottom:14px}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .label{font-size:11px;color:#5a5a72;letter-spacing:.06em;margin-bottom:5px}
        .section-title{font-family:'Syne',sans-serif;font-size:13px;font-weight:700;letter-spacing:.1em;color:#5a5a72;text-transform:uppercase;margin-bottom:14px}
      `}</style>

      {/* Toast */}
      {toast && (
        <div style={{
          position:"fixed",top:20,right:20,zIndex:1000,
          background: toast.type==="warn" ? "#2a2010" : toast.type==="err" ? "#3a1515" : "#1a2a1a",
          border: `1px solid ${toast.type==="warn"?"#4a3010":toast.type==="err"?"#6a2020":"#2a4a2a"}`,
          borderRadius:12,padding:"12px 18px",fontSize:13,
          animation:"toastIn .25s ease",boxShadow:"0 8px 32px rgba(0,0,0,.5)",
          maxWidth:320,color:"#eeeae0",lineHeight:1.4
        }}>
          {toast.msg}
        </div>
      )}

      {/* Sending overlay */}
      {sending && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.6)",zIndex:900,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div style={{background:"#111118",border:"1px solid #252535",borderRadius:16,padding:"28px 40px",textAlign:"center"}}>
            <div style={{fontSize:32,marginBottom:12}}>📧</div>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:16,marginBottom:6}}>Sending email alert…</div>
            <div style={{fontSize:12,color:"#5a5a72"}}>Notifying assignee of new task</div>
          </div>
        </div>
      )}

      <div style={{maxWidth:580,margin:"0 auto",padding:"32px 18px 60px"}}>

        {/* Header */}
        <div style={{marginBottom:28}}>
          <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between"}}>
            <div>
              <div style={{fontFamily:"'Syne',sans-serif",fontSize:30,fontWeight:900,letterSpacing:"-.02em",lineHeight:1}}>
                Store<span style={{color:"#f59e42"}}>Base</span>
              </div>
              <div style={{fontSize:11,color:"#3a3a50",letterSpacing:".1em",marginTop:4}}>LOCATIONS · TASKS · TEAM</div>
            </div>
            {overdueCount > 0 && (
              <div className="pill" style={{background:"#3a1515",color:"#f87171",marginTop:4}}>
                ⚠ {overdueCount} overdue
              </div>
            )}
          </div>

          {/* Stats */}
          <div style={{display:"flex",gap:10,marginTop:20}}>
            {[{label:"Stores",val:stores.length,icon:"📍"},{label:"Tasks",val:pendingCount,icon:"📋"},{label:"Team",val:people.length,icon:"👥"}].map(s=>(
              <div key={s.label} style={{flex:1,background:"#111118",border:"1px solid #1e1e2c",borderRadius:12,padding:"12px 14px"}}>
                <div style={{fontSize:18,marginBottom:4}}>{s.icon}</div>
                <div style={{fontFamily:"'Syne',sans-serif",fontSize:22,fontWeight:800}}>{s.val}</div>
                <div style={{fontSize:11,color:"#4a4a60",letterSpacing:".06em"}}>{s.label.toUpperCase()}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div style={{display:"flex",gap:4,background:"#0e0e16",border:"1px solid #1a1a26",borderRadius:12,padding:4,marginBottom:22}}>
          {[["todos","📋 Tasks"],["stores","📍 Stores"],["team","👥 Team"]].map(([k,l])=>(
            <button key={k} className={"tab-btn"+(tab===k?" active":"")} style={{flex:1}} onClick={()=>setTab(k)}>{l}</button>
          ))}
        </div>

        {/* TASKS */}
        {tab==="todos" && (
          <div className="anim-fade">
            {!todoForm && (
              <button className="btn-primary" style={{width:"100%",marginBottom:14,padding:13}} onClick={()=>setTodoForm(true)}>
                + Add Task
              </button>
            )}
            {todoForm && (
              <div className="form-box anim-slide">
                <div className="section-title">New Task</div>
                <div style={{marginBottom:10}}>
                  <div className="label">TASK TITLE *</div>
                  <input value={tTitle} onChange={e=>setTTitle(e.target.value)} placeholder="What needs to be done?" />
                </div>
                <div className="form-row" style={{marginBottom:10}}>
                  <div>
                    <div className="label">STORE LOCATION</div>
                    <select value={tStore} onChange={e=>setTStore(e.target.value)}>
                      <option value="">No store</option>
                      {stores.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <div className="label">DUE DATE</div>
                    <input type="datetime-local" value={tDue} onChange={e=>setTDue(e.target.value)} />
                  </div>
                </div>
                <div style={{marginBottom:10}}>
                  <div className="label">ASSIGN TO (sends email alert)</div>
                  <select value={tPerson} onChange={e=>setTPerson(e.target.value)}>
                    <option value="">Unassigned</option>
                    {people.map(p=><option key={p.id} value={p.id}>{p.name} — {p.email}</option>)}
                  </select>
                  {people.length===0 && <div style={{fontSize:11,color:"#4a4a60",marginTop:5}}>Add team members in the Team tab first.</div>}
                </div>
                <div style={{marginBottom:16}}>
                  <div className="label">NOTE</div>
                  <textarea value={tNote} onChange={e=>setTNote(e.target.value)} placeholder="Optional details…" />
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button className="btn-primary" onClick={addTodo} disabled={!tTitle.trim()}>
                    {tPerson ? "Add & Send Email" : "Add Task"}
                  </button>
                  <button className="btn-ghost" onClick={()=>setTodoForm(false)}>Cancel</button>
                </div>
              </div>
            )}

            {/* Filters */}
            <div style={{display:"flex",gap:7,overflowX:"auto",paddingBottom:4,marginBottom:14,flexWrap:"wrap"}}>
              {[["all","All"],["active","Active"],["done","Done"]].map(([k,l])=>(
                <button key={k} className={"filter-pill"+(filterStatus===k?" active":"")} onClick={()=>setFilterStatus(k)}>{l}</button>
              ))}
              {stores.length>0 && <div style={{width:1,background:"#1e1e2c",margin:"0 2px"}} />}
              {stores.map(s=>(
                <button key={s.id} className={"filter-pill"+(filterStore===s.id?" active":"")} onClick={()=>setFilterStore(filterStore===s.id?"all":s.id)}
                  style={filterStore===s.id?{background:s.color,borderColor:s.color,color:"#0c0c10"}:{}}>{s.name}</button>
              ))}
              {people.length>0 && <div style={{width:1,background:"#1e1e2c",margin:"0 2px"}} />}
              {people.map(p=>(
                <button key={p.id} className={"filter-pill"+(filterPerson===p.id?" active":"")} onClick={()=>setFilterPerson(filterPerson===p.id?"all":p.id)}>{p.name}</button>
              ))}
            </div>

            {filteredTodos.length===0 && (
              <div style={{textAlign:"center",padding:"40px 0",color:"#3a3a50",fontSize:13}}>
                {filterStatus==="done"?"No completed tasks yet.":"No tasks. Add one above!"}
              </div>
            )}
            {filteredTodos.map(todo => {
              const overdue = !todo.done && isOverdue(todo.due);
              const soon    = !todo.done && isDueSoon(todo.due);
              return (
                <div key={todo.id} className="card" style={{opacity:todo.done?.5:1}}>
                  <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                    <button className={"check-box"+(todo.done?" done":"")} onClick={()=>toggleDone(todo.id)}>
                      {todo.done && "✓"}
                    </button>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontWeight:500,fontSize:14,textDecoration:todo.done?"line-through":"none",color:todo.done?"#4a4a60":"#eeeae0",marginBottom:6,lineHeight:1.3}}>
                        {todo.title}
                      </div>
                      <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
                        {todo.storeName && (
                          <span className="pill" style={{background:todo.storeColor+"22",color:todo.storeColor,border:"1px solid "+todo.storeColor+"44"}}>
                            📍 {todo.storeName}
                          </span>
                        )}
                        {todo.assigneeName && (
                          <span className="pill" style={{background:"#1e1e2c",color:"#9898b0",border:"1px solid #2a2a3a"}}>
                            👤 {todo.assigneeName}
                          </span>
                        )}
                        {todo.due && (
                          <span className="pill" style={{
                            background:overdue?"#3a1515":soon?"#2a2010":"#1a1a26",
                            color:overdue?"#f87171":soon?"#fbbf24":"#5a5a72",
                            border:"1px solid "+(overdue?"#6a2020":soon?"#4a3010":"#252535")
                          }}>
                            {overdue?"⚠ ":soon?"⏰ ":""}{fmtDate(todo.due)}
                          </span>
                        )}
                      </div>
                      {todo.note && <div style={{fontSize:12,color:"#4a4a60",marginTop:8,fontStyle:"italic",lineHeight:1.5}}>{todo.note}</div>}
                    </div>
                    <button className="icon-btn" onClick={()=>deleteTodo(todo.id)}>✕</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* STORES */}
        {tab==="stores" && (
          <div className="anim-fade">
            {!storeForm && (
              <button className="btn-primary" style={{width:"100%",marginBottom:14,padding:13}} onClick={()=>setStoreForm(true)}>
                + Add Store Location
              </button>
            )}
            {storeForm && (
              <div className="form-box anim-slide">
                <div className="section-title">New Store</div>
                <div style={{marginBottom:10}}>
                  <div className="label">STORE NAME *</div>
                  <input value={sName} onChange={e=>setSName(e.target.value)} placeholder="e.g. Downtown Branch" />
                </div>
                <div style={{marginBottom:10}}>
                  <div className="label">ADDRESS</div>
                  <input value={sAddr} onChange={e=>setSAddr(e.target.value)} placeholder="123 Main St, City, State" />
                </div>
                <div style={{marginBottom:16}}>
                  <div className="label">PHONE</div>
                  <input value={sPhone} onChange={e=>setSPhone(e.target.value)} placeholder="(555) 000-0000" />
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button className="btn-primary" onClick={addStore} disabled={!sName.trim()}>Add Store</button>
                  <button className="btn-ghost" onClick={()=>setStoreForm(false)}>Cancel</button>
                </div>
              </div>
            )}
            {stores.length===0 && (
              <div style={{textAlign:"center",padding:"40px 0",color:"#3a3a50",fontSize:13}}>No stores yet. Add your first location!</div>
            )}
            {stores.map(s => {
              const storeTodos = todos.filter(t => t.storeId===s.id && !t.done);
              return (
                <div key={s.id} className="card">
                  <div style={{display:"flex",alignItems:"flex-start",gap:14}}>
                    <div style={{width:4,borderRadius:4,alignSelf:"stretch",background:s.color,flexShrink:0}} />
                    <div style={{flex:1}}>
                      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:4}}>
                        <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:16}}>{s.name}</div>
                        <button className="icon-btn" onClick={()=>deleteStore(s.id)}>✕</button>
                      </div>
                      {s.address && <div style={{fontSize:12,color:"#5a5a72",marginBottom:3}}>📍 {s.address}</div>}
                      {s.phone   && <div style={{fontSize:12,color:"#5a5a72",marginBottom:8}}>📞 {s.phone}</div>}
                      <div style={{display:"flex",gap:8}}>
                        <span className="pill" style={{background:s.color+"22",color:s.color,border:"1px solid "+s.color+"44"}}>
                          {storeTodos.length} open {storeTodos.length===1?"task":"tasks"}
                        </span>
                        {storeTodos.some(t=>isOverdue(t.due)) && (
                          <span className="pill" style={{background:"#3a1515",color:"#f87171",border:"1px solid #6a2020"}}>⚠ overdue</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TEAM */}
        {tab==="team" && (
          <div className="anim-fade">
            {!personForm && (
              <button className="btn-primary" style={{width:"100%",marginBottom:14,padding:13}} onClick={()=>setPersonForm(true)}>
                + Add Team Member
              </button>
            )}
            {personForm && (
              <div className="form-box anim-slide">
                <div className="section-title">New Team Member</div>
                <div className="form-row" style={{marginBottom:10}}>
                  <div>
                    <div className="label">FULL NAME *</div>
                    <input value={pName} onChange={e=>setPName(e.target.value)} placeholder="Jane Smith" />
                  </div>
                  <div>
                    <div className="label">ROLE</div>
                    <input value={pRole} onChange={e=>setPRole(e.target.value)} placeholder="Manager, Staff…" />
                  </div>
                </div>
                <div style={{marginBottom:16}}>
                  <div className="label">EMAIL ADDRESS * (for task alerts)</div>
                  <input type="email" value={pEmail} onChange={e=>setPEmail(e.target.value)} placeholder="jane@example.com" />
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button className="btn-primary" onClick={addPerson} disabled={!pName.trim()||!pEmail.trim()}>Add Member</button>
                  <button className="btn-ghost" onClick={()=>setPersonForm(false)}>Cancel</button>
                </div>
              </div>
            )}

            <div style={{background:"#111a28",border:"1px solid #1e2e40",borderRadius:12,padding:"14px 16px",marginBottom:14,fontSize:12,color:"#6a8aaa",lineHeight:1.6}}>
              <strong style={{color:"#7aaad0",display:"block",marginBottom:4}}>📧 How email alerts work</strong>
              When you assign a task to someone, they get an email instantly. To enable real emails, connect a service like Resend or SendGrid. Right now alerts are simulated.
            </div>

            {people.length===0 && (
              <div style={{textAlign:"center",padding:"40px 0",color:"#3a3a50",fontSize:13}}>No team members yet. Add someone to assign tasks!</div>
            )}
            {people.map(p => {
              const assigned = todos.filter(t => t.assigneeId===p.id && !t.done);
              const overduePerson = assigned.filter(t => isOverdue(t.due));
              return (
                <div key={p.id} className="card">
                  <div style={{display:"flex",alignItems:"center",gap:14}}>
                    <div className="avatar" style={{background:p.color+"33",color:p.color,border:"1.5px solid "+p.color+"55",fontSize:13}}>
                      {initials(p.name)}
                    </div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:2,flexWrap:"wrap"}}>
                        <span style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15}}>{p.name}</span>
                        {p.role && <span className="pill" style={{background:"#1a1a26",color:"#5a5a72",border:"1px solid #252535",fontSize:10}}>{p.role}</span>}
                      </div>
                      <div style={{fontSize:12,color:"#4a4a60",marginBottom:6}}>✉ {p.email}</div>
                      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                        <span className="pill" style={{background:p.color+"22",color:p.color,border:"1px solid "+p.color+"44"}}>
                          {assigned.length} open task{assigned.length!==1?"s":""}
                        </span>
                        {overduePerson.length>0 && (
                          <span className="pill" style={{background:"#3a1515",color:"#f87171",border:"1px solid #6a2020"}}>
                            ⚠ {overduePerson.length} overdue
                          </span>
                        )}
                      </div>
                    </div>
                    <button className="icon-btn" onClick={()=>deletePerson(p.id)}>✕</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
